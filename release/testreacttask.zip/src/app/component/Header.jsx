import React from "react";


export default class Header extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1 style={{textAlign: 'center'}}>Test Shopping list</h1>
            </div>
        )
    }

}